console.log("main.js linked");


// var birds = [
//   "Luther the Bird",
//   "Tim the Bird",
//   "Lucy the Bird",
//   "Sara the Bird",
//   "Tommy the Bird",
//   "Billy the Bird",
// ];


